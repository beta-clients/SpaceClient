package net.minecraft.src;

public interface IStatType {
	String func_27192_a(int var1);
}
