package net.minecraft.src;

class Empty1 {
}
