package net.minecraft.src;

public interface J_JsonListener {
	void func_27195_b();

	void func_27204_c();

	void func_27200_d();

	void func_27197_e();

	void func_27194_f();

	void func_27203_g();

	void func_27205_a(String var1);

	void func_27199_h();

	void func_27198_c(String var1);

	void func_27201_b(String var1);

	void func_27196_i();

	void func_27193_j();

	void func_27202_k();
}
