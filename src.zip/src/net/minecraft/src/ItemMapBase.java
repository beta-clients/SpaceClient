package net.minecraft.src;

public class ItemMapBase extends Item {
	protected ItemMapBase(int var1) {
		super(var1);
	}
}
