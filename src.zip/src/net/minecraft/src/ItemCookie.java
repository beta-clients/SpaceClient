package net.minecraft.src;

public class ItemCookie extends ItemFood {
	public ItemCookie(int var1, int var2, boolean var3, int var4) {
		super(var1, var2, var3);
		this.maxStackSize = var4;
	}
}
