package net.minecraft.src;

public class MapCoord {
	public byte field_28217_a;
	public byte field_28216_b;
	public byte field_28220_c;
	public byte field_28219_d;
	final MapData field_28218_e;

	public MapCoord(MapData var1, byte var2, byte var3, byte var4, byte var5) {
		this.field_28218_e = var1;
		this.field_28217_a = var2;
		this.field_28216_b = var3;
		this.field_28220_c = var4;
		this.field_28219_d = var5;
	}
}
